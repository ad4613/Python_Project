import datetime
import cx_Oracle

## 데이터베이스 연동
cx_Oracle.init_oracle_client(config_dir=r"C:\dev\OracleWallet\Wallet_edudb")
con = cx_Oracle.connect(user="roper", password='UTgUGzj_9sHg47', dsn='edudb_high')
cur = con.cursor()

## 0. SQL Import test
sql = """
      SELECT B.ISBN13, B.NAME, B.PUBLISHER, B.DATE_PUB, B.PAGE, B.PRICE, B.BRAND,
            S.BOOKSTORE, S.RATING, S.REVIEW, S.SALES
      FROM BOOKINFO B FULL OUTER JOIN ONLINESTORE S ON B.ISBN13 = S.ISBN13
      WHERE NAME LIKE '%정보처리기사%'
      """
print(sql)

# fetchone : 조회된 결과(Record Set)로부터 데이터 1개를 반환
cur.execute(sql)
while True:
    row = cur.fetchone()
    if row is None:
        break
    print(row)


## 1. 페이지-가격 혼합 그래프 - PAGE, PRICE 변수 사용
import pandas as pd
import matplotlib.pyplot as plt
## matplotlib 두 종류의 그래프 그리기
## https://codetorial.net/matplotlib/two_types_of_graphs.html

### 1) 그래프의 기본 스타일 설정
plt.style.use('default')
plt.rcParams['figure.figsize'] = (4, 3)
plt.rcParams['font.size'] = 12

### 2) 데이터 준비
sql = """
      SELECT DISTINCT NAME, PAGE, PRICE
      FROM BOOKINFO
      WHERE NAME LIKE '%정보처리기사%'
      """

cur.execute(sql)
while True:
    rows = cur.fetchone()
    if rows is None:
        break
    print(rows)
    rows = cur.fetchall()

df = pd.read_sql(sql=sql, con=con)
df

x_name = df.NAME
y1_page = df.PAGE
y2_price = df.PRICE

### 3) 그래프 그리기 : 한 번에 출력할 것
# 한글 폰트(바탕) 사용을 위해서 세팅
from matplotlib import font_manager, rc
font_path = "C:/Windows/Fonts/batang.ttc"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)

fig, ax1 = plt.subplots()
#plt.xticks(rotation=45)    # x축 이름 45도 회전

ax1.plot(x_name, y1_page, '-s', color='green', markersize=7, linewidth=5, alpha=5, label='Page')
ax1.set_ylim(0, 1500)
ax1.set_xlabel('Book')
ax1.set_ylabel('Page')
ax1.tick_params(axis='both', direction='in')
ax1.axes.xaxis.set_visible(False)           # x축을 포함한 label 숨기기 (도서명 너무 긺)

ax2 = ax1.twinx()   # 이중 Y축
ax2.bar(x_name, y2_price, color='deeppink', label='Price', alpha=0.3, width=0.7)
ax2.set_ylim(0, 40000)
ax2.set_ylabel(r'Price')
ax2.tick_params(axis='y', direction='in')
plt.show()

## 2. 페이지 수가 많을 수록 가격이 비싸지는가? : 상관분석 - NAME, PRICE 변수 사용
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.pylab as pylab


## 상관계수가 +1에 가까울수록 위 가설이 맞다고 할 수 있음
sql = """
      select page, price
      from bookinfo
      """

cur.execute(sql)
while True:
    rows = cur.fetchone()
    if rows is None:
        break
    print(rows)
    rows = cur.fetchall()

### PAGE와 PRICE를 데이터 프레임으로 변환 -> 데이터 프레임(pandas) 사용
df = pd.read_sql(sql=sql, con=con)
df

# 추세선을 위한 계산 - 1차원의 polynomial(다항식)을 계산하기 위한 코드입니다.
z = np.polyfit(df.PAGE, df.PRICE, 1) # (X,Y,차원) 정의
p = np.poly1d(z)

### 산점도
plt.figure(figsize = (8,6))
plt.scatter(df.PAGE, df.PRICE)
plt.xlabel("페이지 수(쪽)")
plt.ylabel("도서 가격(원)")
plt.title("페이지 수(Page)와 도서 가격(Price)에 대한 산점도", fontsize=15)
pylab.plot(df.PAGE, df.PRICE, 'o') #산점도를 뜻할 때 'o'라고 합니다.
pylab.plot(df.PAGE, p(df.PAGE), "r--")

plt.show()

### pandas의 corr(): 상관관계 측정 함수 - 피어슨 상관계수 측정
df.corr(method='pearson')
### r이 -1.0과 -0.7 사이이면, 강한 음적 선형관계,
### r이 -0.7과 -0.3 사이이면, 뚜렷한 음적 선형관계,
### r이 -0.3과 -0.1 사이이면, 약한 음적 선형관계,
### r이 -0.1과 +0.1 사이이면, 거의 무시될 수 있는 선형관계,
### r이 +0.1과 +0.3 사이이면, 약한 양적 선형관계,
### r이 +0.3과 +0.7 사이이면, 뚜렷한 양적 선형관계,
### r이 +0.7과 +1.0 사이이면, 강한 양적 선형관계
#### (출처 : 위키백과 - 상관 분석)

### 상관계수 0.77 = 강한 양적 선형관계 = 교재의 페이지 수와 가격은 매우 비례한다.

### numpy 배열을 통하여 상관계수 및 p-value 구하기
page = np.array(df.PAGE)
price = np.array(df.PRICE)

from scipy import stats
pearsonr, pvalue = stats.pearsonr(page, price)
print(pearsonr)
print(pvalue)
### p-value가 0.05보다 작으므로, 유의수준 5% 하에서 상관계수가 통계적으로 유의한다.
### 즉, 페이지 수와 도서 가격 사이에 선형적인 상관성이 있다.


## 3. 리뷰건수가 많을수록 별점이 내려가는가?(반비례하는가?) : 상관분석
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.pylab as pylab

## 상관계수가 -1에 가까울수록 위 가설이 맞다고 할 수 있음
sql = """
      select review, rating
      from onlinestore
      WHERE RATING IS NOT NULL AND REVIEW IS NOT NULL
      """

cur.execute(sql)
while True:
    rows = cur.fetchone()
    if rows is None:
        break
    print(rows)
    rows = cur.fetchall()    # 예시 데이터: 각 변수의 첫 행 출력

### PAGE와 PRICE를 데이터 프레임으로 변환 -> pandas 라이브러리 사용
df = pd.read_sql(sql=sql, con=con)
df

# 추세선을 위한 계산 - 1차원의 polynomial(다항식)을 계산하기 위한 코드입니다.
z = np.polyfit(df.REVIEW, df.RATING, 1) # (X,Y,차원) 정의
p = np.poly1d(z)

### 산점도
plt.figure(figsize = (8,6))
plt.scatter(df.REVIEW, df.RATING)

plt.xlabel("리뷰건수(건)")
plt.ylabel("별점(점)")
plt.title("리뷰건수(Review)와 별점(Rating)에 대한 산점도", fontsize=15)
pylab.plot(df.REVIEW, df.RATING, 'o') #산점도를 뜻할 때 'o'라고 합니다.
pylab.plot(df.REVIEW, p(df.RATING), "r--")
plt.show()

### numpy 라이브러리를 사용하여 두 변수의 상관계수 값 출력
df.corr(method='pearson')
### r이 -1.0과 -0.7 사이이면, 강한 음적 선형관계,
### r이 -0.7과 -0.3 사이이면, 뚜렷한 음적 선형관계,
### r이 -0.3과 -0.1 사이이면, 약한 음적 선형관계,
### r이 -0.1과 +0.1 사이이면, 거의 무시될 수 있는 선형관계,
### r이 +0.1과 +0.3 사이이면, 약한 양적 선형관계,
### r이 +0.3과 +0.7 사이이면, 뚜렷한 양적 선형관계,
### r이 +0.7과 +1.0 사이이면, 강한 양적 선형관계

### 상관계수 -0.31 = 뚜렷한 음적 선형관계 = 별점과 리뷰 건수는 다소 반비례한다.

### numpy를 통하여 상관계수 및 p-value 구하기
review = np.array(df.REVIEW)
rating = np.array(df.RATING)
output1 = review[np.isfinite(review)]     # NumPy 배열에서 NaN 값 제거
output2 = rating[np.isfinite(rating)]     # NumPy 배열에서 NaN 값 제거

import scipy.stats
pearsonr, pvalue = stats.pearsonr(output1, output2)
print(pearsonr)
print(pvalue)
### p-value가 0.05보다 크므로, 유의수준 5% 하에서 상관계수가 통계적으로 유의하지 않음.
### 즉, 별점과 리뷰 건수 사이에 선형적인 상관성이 없다.

## 4. 브랜드별 판매지수 평균 (YES24, 알라딘)
import pandas as pd
import matplotlib.pyplot as plt

## BRAND, SALES 변수 사용
sql = """
      SELECT B.BRAND, round(avg(S.SALES),1) sales_mean
      FROM BOOKINFO B LEFT JOIN ONLINESTORE S ON B.ISBN13 = S.ISBN13
      GROUP BY B.BRAND
      ORDER BY round(avg(S.SALES),1) DESC
      """

# fetchall
cur.execute(sql)
rows = cur.fetchall()
if rows:
    for row in rows:
        print(row)

### 데이터 프레임으로 변환 -> pandas사용
df = pd.read_sql(sql=sql, con=con)
df


## 판매지수로 점유율 표시
# 한글 폰트 사용을 위해서 세팅
from matplotlib import font_manager, rc
font_path = "C:/Windows/Fonts/HMKMM.TTF"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)
plt.pie(df.SALES_MEAN, labels=df.BRAND, autopct='%.1f%%', startangle=90, counterclock=False)


## 5. 출판사(브랜드)별 리뷰건수 비교
import matplotlib.pyplot as plt
import pandas as pd

## 가로 막대그래프 : bar() 대신 barh() 함수 사용
sql = """
      SELECT B.BRAND brand, SUM(S.REVIEW) AS review_total
      FROM BOOKINFO B LEFT JOIN ONLINESTORE S ON B.ISBN13 = S.ISBN13
      WHERE S.REVIEW IS NOT NULL
      GROUP BY B.BRAND
      ORDER BY SUM(S.REVIEW) DESC
      """

# fetchall
cur.execute(sql)
rows = cur.fetchall()
if rows:
    for row in rows:
        print(row)

### 데이터 프레임으로 변환 -> pandas사용
df = pd.read_sql(sql=sql, con=con)
df
df = df.sort_values(by='REVIEW_TOTAL', axis=0, ascending=False)    # 내림차순 정렬
len(df)

# 한글 폰트(휴면명조) 사용을 위해서 세팅
from matplotlib import font_manager, rc
font_path = "C:/Windows/Fonts/HMKMM.TTF"
font = font_manager.FontProperties(fname=font_path).get_name()
rc('font', family=font)
plt.barh(df.BRAND, df.REVIEW_TOTAL)
